const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || '/api').replace(/\/$/, '');

export async function fetchLatestTelemetry(signal) {
  const response = await fetch(`${API_BASE_URL}/telemetry`, {
    method: 'GET',
    headers: { Accept: 'application/json' },
    cache: 'no-store',
    signal,
  });
  if (!response.ok) throw new Error(`API respondeu HTTP ${response.status}`);
  const payload = await response.json();
  return Array.isArray(payload.items) ? payload.items : [];
}

export function formatTelemetryTime(timestamp) {
  if (!timestamp) return 'Sem atualização';
  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return 'Data inválida';
  return date.toLocaleString('pt-BR');
}
