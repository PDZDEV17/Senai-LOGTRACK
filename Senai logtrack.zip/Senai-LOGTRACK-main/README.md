# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some Oxlint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Oxc](https://oxc.rs)
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/)

## React Compiler

The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).

## Expanding the Oxlint configuration

If you are developing a production application, we recommend using TypeScript with type-aware lint rules enabled. Check out the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) for information on how to integrate TypeScript and Oxlint's TypeScript related rules in your project.

## Integração HTTP com ESP32 (GPS)

O rastreamento consulta `GET /api/telemetry` a cada 5 segundos. O ESP32 publica sua última posição em `POST /api/telemetry`. O identificador `deviceId` deve corresponder ao campo `vehicle` do transporte no sistema (por exemplo, `TR-008`). Veículos sem coordenadas recebidas continuam com posição demonstrativa, identificada como tal.

### 1. Iniciar localmente

Requisitos: Node.js 20.19+ ou 22.12+ (compatível com Vite 8).

Terminal 1 — iniciar a API:

```bash
DEVICE_TOKEN="substitua-por-um-token-longo" npm run api
```

Terminal 2 — iniciar o site:

```bash
npm install
npm run dev
```

A API local fica em `http://localhost:3001`. Para o site conversar com ela durante o desenvolvimento, crie `.env.local` com:

```env
VITE_API_BASE_URL=http://localhost:3001/api
```

Reinicie o Vite após mudar variáveis `VITE_*`.

### 2. Formato da mensagem do ESP32

Envie JSON com latitude/longitude numéricas e o identificador do veículo:

```json
{
  "deviceId": "TR-008",
  "latitude": -5.0782,
  "longitude": -42.7865,
  "timestamp": "2026-10-21T20:00:00Z",
  "accuracy": 8.5
}
```

`timestamp` e `accuracy` são opcionais. A API valida os limites de latitude (-90 a 90) e longitude (-180 a 180), e mantém a última posição de cada dispositivo. O token deve ser enviado no cabeçalho `X-Device-Token` (ou `Authorization: Bearer ...`).

### 3. Testar a API sem ESP32

Com a API em execução, use o mesmo token que configurou ao iniciar o servidor:

```bash
curl http://localhost:3001/api/health

curl -X POST http://localhost:3001/api/telemetry \
  -H 'Content-Type: application/json' \
  -H 'X-Device-Token: substitua-por-um-token-longo' \
  -d '{"deviceId":"TR-008","latitude":-5.0782,"longitude":-42.7865}'

curl http://localhost:3001/api/telemetry
```

Se o POST retornar `201`, abra o rastreamento: o veículo `TR-008` deve usar as coordenadas enviadas e a tela deve indicar a API conectada. O arquivo `server/telemetry.json` armazena as últimas posições no disco.

### 4. Hospedagem pela internet

- Hospede a API em um serviço Node.js que mantenha o processo ativo e tenha armazenamento persistente para `server/telemetry.json` (ou configure `TELEMETRY_FILE` para um disco persistente). Hospedagens serverless/efêmeras podem apagar esse arquivo e não são adequadas sem trocar o armazenamento por banco de dados.
- Publique a API atrás de HTTPS e configure `DEVICE_TOKEN` como variável secreta no servidor. Não coloque o token dentro do React nem em variáveis `VITE_*`: elas ficam públicas no navegador.
- Configure `ALLOWED_ORIGINS` com a origem exata do site, por exemplo `https://seu-site.example`. Configure `VITE_API_BASE_URL` no build do frontend para a URL HTTPS da API, por exemplo `https://api.seu-dominio.example/api`.
- Configure o ESP32 para enviar a URL HTTPS `https://api.seu-dominio.example/api/telemetry`. Não exponha a API por HTTP sem TLS na internet.
- O endpoint GET de telemetria está público nesta primeira versão para permitir que o site leia as posições sem colocar segredos no navegador. Antes de usar com veículos reais, restrinja a leitura por autenticação de usuários e aplique controles de acesso, porque localização GPS pode ser dado sensível.
- A autenticação por token compartilhado é uma base para protótipo. Use um token aleatório forte, mantenha-o apenas no firmware/servidor e planeje rotação se o dispositivo for perdido ou comprometido.

A API usa apenas módulos nativos do Node.js; não é necessária dependência adicional para o backend.
