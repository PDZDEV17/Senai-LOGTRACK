import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3001);
const DEVICE_TOKEN = process.env.DEVICE_TOKEN;
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '').split(',').map((v) => v.trim()).filter(Boolean);
const DATA_FILE = process.env.TELEMETRY_FILE || path.join(__dirname, 'telemetry.json');

function readTelemetry() {
  try {
    const parsed = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    if (error.code !== 'ENOENT') console.error('Não foi possível ler telemetria:', error.message);
    return [];
  }
}
function writeTelemetry(items) {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(items, null, 2));
}
function send(res, status, body, origin) {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Device-Token',
  };
  if (origin && (ALLOWED_ORIGINS.length === 0 || ALLOWED_ORIGINS.includes(origin))) headers['Access-Control-Allow-Origin'] = origin;
  res.writeHead(status, headers);
  res.end(JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 16 * 1024) {
        reject(new Error('BODY_TOO_LARGE'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(data || '{}')); }
      catch { reject(new Error('INVALID_JSON')); }
    });
    req.on('error', reject);
  });
}
function validDeviceId(value) {
  return typeof value === 'string' && /^[a-zA-Z0-9_-]{1,64}$/.test(value);
}

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin;
  if (origin && ALLOWED_ORIGINS.length && !ALLOWED_ORIGINS.includes(origin)) {
    return send(res, 403, { error: 'Origin não permitido pelo CORS.' });
  }
  if (req.method === 'OPTIONS') return send(res, 204, {} , origin);
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);

  if (req.method === 'GET' && url.pathname === '/api/health') {
    return send(res, 200, { ok: true, service: 'senai-logtrack-api' }, origin);
  }
  if (req.method === 'GET' && url.pathname === '/api/telemetry') {
    return send(res, 200, { items: readTelemetry() }, origin);
  }
  if (req.method === 'POST' && url.pathname === '/api/telemetry') {
    if (!DEVICE_TOKEN) return send(res, 503, { error: 'API sem DEVICE_TOKEN configurado. Configure a variável no servidor.' }, origin);
    const suppliedToken = req.headers['x-device-token'] || String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!suppliedToken || suppliedToken !== DEVICE_TOKEN) return send(res, 401, { error: 'Token do dispositivo inválido.' }, origin);
    let body;
    try { body = await readBody(req); }
    catch (error) {
      const status = error.message === 'BODY_TOO_LARGE' ? 413 : 400;
      return send(res, status, { error: error.message === 'BODY_TOO_LARGE' ? 'JSON maior que o limite de 16 KB.' : 'JSON inválido.' }, origin);
    }
    const { deviceId, latitude, longitude, timestamp, accuracy } = body;
    if (!validDeviceId(deviceId)) return send(res, 400, { error: 'deviceId obrigatório; use 1–64 caracteres alfanuméricos, _ ou -.' }, origin);
    if (typeof latitude !== 'number' || !Number.isFinite(latitude) || latitude < -90 || latitude > 90) return send(res, 400, { error: 'latitude deve ser um número entre -90 e 90.' }, origin);
    if (typeof longitude !== 'number' || !Number.isFinite(longitude) || longitude < -180 || longitude > 180) return send(res, 400, { error: 'longitude deve ser um número entre -180 e 180.' }, origin);
    const parsedTimestamp = timestamp ? new Date(timestamp) : new Date();
    if (Number.isNaN(parsedTimestamp.getTime())) return send(res, 400, { error: 'timestamp deve ser uma data válida em formato ISO 8601.' }, origin);
    const item = {
      deviceId, latitude, longitude, timestamp: parsedTimestamp.toISOString(),
      ...(typeof accuracy === 'number' && Number.isFinite(accuracy) && accuracy >= 0 ? { accuracy } : {}),
    };
    const items = readTelemetry();
    const index = items.findIndex((entry) => entry.deviceId === deviceId);
    if (index >= 0) items[index] = item;
    else items.push(item);
    try { writeTelemetry(items); }
    catch (error) {
      console.error('Não foi possível salvar telemetria:', error.message);
      return send(res, 500, { error: 'Falha ao salvar a telemetria.' }, origin);
    }
    return send(res, 201, { ok: true, item }, origin);
  }
  return send(res, 404, { error: 'Rota não encontrada.' }, origin);
});

server.listen(PORT, '0.0.0.0', () => console.log(`SENAI-LOGTRACK API ouvindo na porta ${PORT}`));
